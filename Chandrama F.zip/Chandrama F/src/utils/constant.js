export const BackenUrl='https://chandramarealconbackend-wsct.onrender.com';
// export const BackenUrl = "http://localhost:5000/api";